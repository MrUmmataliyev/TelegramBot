﻿namespace _25_lesson_TelegramBot_Basic
{
    public class Valyuta
    {
        public string title { get; set; } = String.Empty;
        public string code { get; set; } = String.Empty;
        public string cb_price { get; set; } = String.Empty;
        public string nbu_buy_price { get; set; } = String.Empty;
        public string nbu_cell_price { get; set; } = String.Empty;
        public string date { get; set; } = String.Empty;
    }
}
