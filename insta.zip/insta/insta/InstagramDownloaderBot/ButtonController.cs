﻿using Telegram.Bot.Types.ReplyMarkups;

namespace insta
{
    public class ButtonController
    {
        public static ReplyKeyboardMarkup replyKeyboardMarkup = new(
            new[]
        {
            new KeyboardButton[] { " Rasm kiritish uchun bosing!" },
            new KeyboardButton[] { " Video kiritish uchun bosing!" }
        })
        {
            ResizeKeyboard = true
        };
    }
}
