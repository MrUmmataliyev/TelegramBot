﻿using insta;
// 6827225607:AAHMZ2m1n61NuZq7FBq1dkpklz0jJknsJQk
var token = "6555041163:AAESZzhkcd6lVZ78jRckCzNA9ImV_nA1q9I";
Server server = new Server(token);
try
{
    server.Run().Wait();
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}